Homepage: http://qamaraskari.com/ The Latex sources and MATLAB implementation of my algorithms and benchmark functions are also available at my homepage. I'll be happy to collaborate with someone interested in to work on my algorithms and enhance them or hybridize them with existing techniques or apply them to solve real-world applications. My research interests and current projects are also available at my homepage.

# PO
Political Optimizer
main.m to run the algorithm.
