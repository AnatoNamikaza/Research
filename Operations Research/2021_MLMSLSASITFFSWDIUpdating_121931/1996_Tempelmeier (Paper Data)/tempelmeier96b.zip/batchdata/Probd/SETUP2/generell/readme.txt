G026*.cap aus [setup1]
G826*.cap als Kopie von G026*.cap

Dateien entsprechen also denen aus [setup1\generell], haben nur andere Dateinamen
