G016*.cap aus [setup1]
G816*.cap ist Kopie von G016*.cap
